book = {"chap1":10 ,"chap2":20 ,"chap3":30 }
# display dictionary
print(book)

if 'chap1' in book:
    # display single value
    print(book['chap1'])
else:
    print('key doesnt exist')

# add new key-value pairs
book['chap4'] = 40
book['chap5'] = 50
book['chap6'] = 60
print(book)
# display key sonly
print(book.keys())
print(book.values())  # display values

print(book.items())  # display key-value pairts
# method1
newbook = {"chap7":70,"chap8":80}
finalbook = {**book,**newbook}
print(finalbook)

#method2
book.update(newbook)
print(book)