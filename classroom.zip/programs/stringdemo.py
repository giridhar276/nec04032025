name = "python programming"
print(name)
print("I love",name)
# slicing # string[start:stop:step]
print(name[0])
print(name[2])
print(name[0:10])
print(name[0:10:1])  # 1 is the default step value( incremental value)
print(name[0:10:2])
print(name[:])  #string[0:18]
print(name[::]) #string[0:18:1]
print(name[-1])
print(name[-2])
print(name[-4:])
print(name[::-1])

# string methods  
# using below mehods ... we are not making any changes to the orig str
name = "python programming"
print(name.capitalize())
print(name.title())
print(name.upper())
print(name.lower())
print(name.count("p"))
print(name.count("P"))
print(name.split(" "))
print(name.isalnum())
print(name.replace("python","R"))

aname = "I love {} and {}" #template
print(aname.format("python","R"))
print(aname.format("sita","gita"))

bname = " python  "
print(len(bname))
print(len(bname.strip()))
print(len(bname.lstrip()))
print(len(bname.rstrip()))

first,second,third = 10,20,30
a = 10
b = 2
if a > b :
    print("A is greater than B")
    print("Inside if ")
    print("still inside if")

# simple if
if name.startswith("p"):
    print("Its python")

# if-else condition
if name.startswith("p"):
    print("Its python")
else:
    print("its some other language")

# if -elif-elif-elif-else
name = input("Enter any language?")
if name.startswith("p"):
    print("python")
elif name.startswith("r"):
    print("ruby")
elif name.startswith("j"):
    print("java")
else:
    print("some other language")



name = 'python'
if len(name) == 6  or name.endswith("n"): # one of the cond tobe true
    print("condition is true")

if len(name) == 6  and name.endswith("n"):
    print("condition is true")