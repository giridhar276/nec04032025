
alist = [10,20,30]
alist[0] = 100
alist.append(40)
print(alist)


atup = (10,20,30)
print(atup)
alist = list(atup)  # typecasting : converting from one object to another object
alist.append(40)
atup = tuple(alist)
print(atup)