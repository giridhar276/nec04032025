alist =[10,256,65,76,34,8,19,95]
print(alist)

alist.append(74)  # adding single object
print("After appending:",alist)

alist.extend([34,29,84])  # adding multiple values
print("After extending:",alist)

alist.insert(0,100)   # list.insert(index,value)
print("after inserting:",alist)

alist.pop(0)  #list.pop(index)  # value at that index is removed
print('After pop :',alist)

if 760 in alist:
    alist.remove(760) # if 76 exists in list .. will be removed
    print('After removing :',alist)
else:
    print("Value is not existing")

alist.sort()
print('After sorting:',alist)
alist.sort(reverse=True)
print('After sorting:',alist)

alist.reverse()
print('After reversing:',alist)

blist = [50,60]
total = alist + blist
print(total)

final = "python" + "programing"
print(final)



a = int(input("A:"))
b = int(input("B:"))
t = "{} is greater than {}"
if a > b :
    print(t.format(a, b))
elif b > a :
    print(t.format(b, a))
else: 
    print("Values are equal")