# for ( i = 1: i <=10 ; i++ ) {   }

# range(start,stop,incremental)
for i in range(1,11):
    print(i)

for i in range(2,10,2):  # range() is the function like print,list,tuple
    print(i)

string = "python"
for char in string:
    print(char)

alist = [10,20,30]
for val in alist:
    print(val)

book = {"chap1":10 ,"chap2":20}
for key in book.keys():
    print(key)

for value in book.values():
    print(value)

for key,value in book.items():
    print(key,value)


alist = [10,20,30]
alist.reverse()
for val in alist:
    print(val)

alist = [10,20,30]
for val in alist[::-1]:
    print(val)


