
# reading the file line by line
fobj = open("employee.csv","r") 
for line in fobj:
    print(line.strip())
fobj.close()

# method2
fobj = open("employee.csv","r") 
print(fobj.readlines())
fobj.close()

#method3
fobj = open("employee.csv","r") 
print(fobj.read())  # the whole file content will be one single string
fobj.close()

#method4
import csv
fobj = open("employee.csv","r") 
reader = csv.reader(fobj)  # convert fobj to csv object
for line in reader:
    print(line)

#method4
import pandas
df = pandas.read_csv('employee.csv')
print(df)



