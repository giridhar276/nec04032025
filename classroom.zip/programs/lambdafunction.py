# EVery OS contains set of processes that are running
# Every process contains set of system calls
# Eg: exec() fork() open()
# legacy way or tradtional way
def display(a,b):
    c = a + b
    return c
total = display(10,20)
print(total)

# pythonic way
#lambda function or nameless function  or anonymous function
# lambda is the single liner function
# Execution becomes faster using lambda

#syntax
#functionname = lambda varaibles:expression

display = lambda x,y: x+y
total = display(10,20)
print(total)


# lambda with condition
largest = lambda a, b: a if a > b else b
print(largest(10,20))