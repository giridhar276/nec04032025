
'''
1. display current working directory
2. display login name
3. display all environment variables
4. display today's date ( timestamp )
5. display sep months calendar
6. display all .py files and its size in bytes
7. display the modified time of employee.csv file
8. display current process id
9. set an environment variables. ( Eg.    TEST_PATH = "C:/Users/Admin/")
10. Lock and unlock a file using os.open and os.close
11. Retrieve the current system's load average.
12. display python version

'''
import os
import datetime
import time
import dateutil
import psutil
import calendar
import sysconfig
import sys

print(os.getcwd())

print(os.getlogin())

print(os.environ)


for key,value in os.environ.items():
    print(key)
    print(value)
    print("-----------------")



print(datetime.datetime.now())
print(time.localtime())
print(datetime.date.today())
print(time.time())


print(calendar.month(2025,10))
print(calendar.calendar(2025))


for file in os.listdir():
    print(file.ljust(20) , os.path.getsize(file),"bytes")



filename = "task1.py"

modifiedtime = os.path.getmtime(filename)
print(modifiedtime)
print(datetime.datetime.fromtimestamp(modifiedtime))


# process id
print(os.getpid())


#create environment variable
os.environ["MY_ENV_VAR"] = "test"


# lock and unlocking  afile
#descriptor = os.open("adult.csv", os.O_RDWR)
#os.close(descriptor)


#python version
print(sys.version)
print(sys.version_info)
print(sysconfig.get_python_version())

