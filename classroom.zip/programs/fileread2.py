
try:
    # reading the file line by line
    fobj = open("employee.csv","r") 
    for line in fobj:
        print(line.strip())
    fobj.close()
except FileNotFoundError as err:
    print(err)
    print("File not found.. pl check")
except TypeError as err:
    print("Invalid operation",err)
except (IndexError,KeyError) as err:
    print("Invalid index or key.. pl check")
except Exception as err:  # default exception
    print(err)






try:
    # reading the file line by line
    fobj = open("employee.csv","r") 
    for line in fobj:
        print(line.strip())
    fobj.close()
except Exception as e:  # default exception
    print(e)




try:
    # reading the file line by line
    with open("employee.csv","r") as fobj:
        for line in fobj:
            print(line.strip())

except FileNotFoundError as err:
    print(err)
    print("File not found.. pl check")
except TypeError as err:
    print("Invalid operation",err)
except (IndexError,KeyError) as err:
    print("Invalid index or key.. pl check")
except Exception as err:  # default exception
    print(err)