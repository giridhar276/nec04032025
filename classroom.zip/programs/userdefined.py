
# fixed arguments
def display(a,b):
    c = a + b
    return c
total = display(10,20)
print(total)

# default arguments
def display(a = 0,b = 0,c = 0,d = 0):
    print(a,b,c,d)
display()
display(10)
display(10,20)
display(10,20,30)
display(10,20,30,40)

#variable length arguments
def display(*args):
    print(type(args))
    for val in args:
        print(val)
display(10,20,5,90,94,29,40,3,5,4,32,45,3,98,23,45,3,98,3,"python")


def display(**kwargs):
    print(kwargs)
    for key,value in kwargs.items():
        print(key,value)

display(chap1 = 10 ,chap2 = 20)