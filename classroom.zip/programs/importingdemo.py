# method1 - importing all the methods
import math  # all the methods are imorting to your program
print(math.cos(1))
print(math.log(1))
print(len(dir(math)))


# method2 - importing with alias name
import matplotlib.pyplot as plt
plt.plot([10,20],[20,30])
plt.show()

#method3 - importing required methods only
from math import sin,log,tan   # we are not importing everything .. just importing only few
print(sin(1))
print(tan(3))