
#   Create a new directory called "test_directory". After creating it, remove the directory.

import os
try:
    dirname = "test_directory"
    if not os.path.isdir(dirname):
        os.mkdir(dirname)
    #os.rmdir(dirname)
except Exception as err:
    print(err)