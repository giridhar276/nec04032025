# traditional way # legacy way
# write mode
# In write mode ... If file is not existing .. file gets created
#                   if file is already existing....it overwrites the existing content first
fobj = open("customers.txt","w")

fobj.write("tcs\n")
fobj.write("cts\n")
fobj.write("infy\n")

for val in range(1,11):
    fobj.write(str(val)  + "\n")

fobj.close()


# pythonic way
# context manager
# If any line starts with keyword 'with' .. it is called as context manager
# Advantage: file will be closed automatically
with open("customers.txt","w") as fobj:
    fobj.write("tcs\n")
    fobj.write("cts\n")
    fobj.write("infy\n")



