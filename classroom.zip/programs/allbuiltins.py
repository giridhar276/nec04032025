
# display al the list of builtin exceptions and functions
print(dir(__builtins__))
