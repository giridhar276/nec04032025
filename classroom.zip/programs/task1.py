#Write a script that lists all files and directories in the current working directory line by line.

import os
try:
    files = os.listdir()
    for file in files:
        print(file)
except Exception as err:
    print(err)


import os
try:
    files = os.listdir()
    for file in files:
        if os.path.isfile(file):
            print(file,"is a file")
            print("Size:", os.path.getsize(file),"bytes")
        elif os.path.isdir(file):
            print(file,"is a directory")
except Exception as err:
    print(err)